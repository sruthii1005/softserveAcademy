## to help in the creation of more tests
npx playwright codegen demo.playwright.dev/todomvc

## to run the tests
npx playwright test
